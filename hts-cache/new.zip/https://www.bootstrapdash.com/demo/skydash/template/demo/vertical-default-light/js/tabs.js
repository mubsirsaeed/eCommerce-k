<!DOCTYPE html>
<html lang="en-US">
<head>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>Page not found - Bootstrap Themes and Templates</title>
	<link rel="profile" href="http://gmpg.org/xfn/11" />
	<link rel="pingback" href="https://www.bootstrapdash.com/xmlrpc.php" />
			
	<meta name='robots' content='noindex, follow' />

	<!-- This site is optimized with the Yoast SEO plugin v16.4 - https://yoast.com/wordpress/plugins/seo/ -->
	<meta property="og:locale" content="en_US" />
	<meta property="og:title" content="Page not found - Bootstrap Themes and Templates" />
	<meta property="og:site_name" content="Bootstrap Themes and Templates" />
	<script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"WebSite","@id":"https://www.bootstrapdash.com/#website","url":"https://www.bootstrapdash.com/","name":"Bootstrap Themes and Templates","description":"Bootstrap Themes and Templates","potentialAction":[{"@type":"SearchAction","target":"https://www.bootstrapdash.com/?s={search_term_string}","query-input":"required name=search_term_string"}],"inLanguage":"en-US"}]}</script>
	<!-- / Yoast SEO plugin. -->


<link rel='dns-prefetch' href='//www.googletagmanager.com' />
<link rel='dns-prefetch' href='//www.google.com' />
<link rel='dns-prefetch' href='//cdnjs.cloudflare.com' />
<link rel='dns-prefetch' href='//s.w.org' />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.1\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/www.bootstrapdash.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.7.8"}};
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([55357,56424,8205,55356,57212],[55357,56424,8203,55356,57212])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='dashicons-css'  href='https://www.bootstrapdash.com/wp-includes/css/dashicons.min.css?ver=5.7.8' type='text/css' media='all' />
<link rel='stylesheet' id='thickbox-css'  href='https://www.bootstrapdash.com/wp-includes/js/thickbox/thickbox.css?ver=5.7.8' type='text/css' media='all' />
<link rel='stylesheet' id='bdpopupcss-css'  href='https://www.bootstrapdash.com/wp-content/themes/bootstradash/assets/css/popup.css?ver=5.7.8' type='text/css' media='all' />
<link rel='stylesheet' id='wp-block-library-css'  href='https://www.bootstrapdash.com/wp-includes/css/dist/block-library/style.min.css?ver=5.7.8' type='text/css' media='all' />
<link rel='stylesheet' id='wc-block-vendors-style-css'  href='https://www.bootstrapdash.com/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/vendors-style.css?ver=5.1.0' type='text/css' media='all' />
<link rel='stylesheet' id='wc-block-style-css'  href='https://www.bootstrapdash.com/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/style.css?ver=5.1.0' type='text/css' media='all' />
<link rel='stylesheet' id='affwp-forms-css'  href='https://www.bootstrapdash.com/wp-content/plugins/affiliate-wp/assets/css/forms.min.css?ver=2.6.8' type='text/css' media='all' />
<link rel='stylesheet' id='contact-form-7-css'  href='https://www.bootstrapdash.com/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.4.1' type='text/css' media='all' />
<link rel='stylesheet' id='eh-style-css'  href='https://www.bootstrapdash.com/wp-content/plugins/eh-stripe-payment-gateway/assets/css/eh-style.css?ver=3.2.8' type='text/css' media='all' />
<link rel='stylesheet' id='facebook-product-catalog-sync-css'  href='https://www.bootstrapdash.com/wp-content/plugins/facebook-product-catalog-sync/public/css/facebook-product-catalog-sync-public.css?ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='cookie-law-info-css'  href='https://www.bootstrapdash.com/wp-content/plugins/webtoffee-gdpr-cookie-consent/public/css/cookie-law-info-public.css?ver=2.3.3' type='text/css' media='all' />
<link rel='stylesheet' id='cookie-law-info-gdpr-css'  href='https://www.bootstrapdash.com/wp-content/plugins/webtoffee-gdpr-cookie-consent/public/css/cookie-law-info-gdpr.css?ver=2.3.3' type='text/css' media='all' />
<style id='cookie-law-info-gdpr-inline-css' type='text/css'>
.cli-modal-content, .cli-tab-content { background-color: #ffffff; }.cli-privacy-content-text, .cli-modal .cli-modal-dialog, .cli-tab-container p, a.cli-privacy-readmore { color: #000000; }.cli-tab-header { background-color: #f2f2f2; }.cli-tab-header, .cli-tab-header a.cli-nav-link,span.cli-necessary-caption,.cli-switch .cli-slider:after { color: #000000; }.cli-switch .cli-slider:before { background-color: #ffffff; }.cli-switch input:checked + .cli-slider:before { background-color: #ffffff; }.cli-switch .cli-slider { background-color: #e3e1e8; }.cli-switch input:checked + .cli-slider { background-color: #28a745; }.cli-modal-close svg { fill: #000000; }.cli-tab-footer .wt-cli-privacy-accept-all-btn { background-color: #00acad; color: #ffffff}.cli-tab-footer .wt-cli-privacy-accept-btn { background-color: #00acad; color: #ffffff}.cli-tab-header a:before{ border-right: 1px solid #000000; border-bottom: 1px solid #000000; }
</style>
<style id='woocommerce-inline-inline-css' type='text/css'>
.woocommerce form .form-row .required { visibility: visible; }
</style>
<link rel='stylesheet' id='wt-smart-coupon-store-credit-css'  href='https://www.bootstrapdash.com/wp-content/plugins/wt-smart-coupon-pro/admin/store-credit/public/css/wt-smart-coupon-store-credit.css?ver=1.3.4' type='text/css' media='all' />
<link rel='stylesheet' id='wt-smart-coupon-banner-css'  href='https://www.bootstrapdash.com/wp-content/plugins/wt-smart-coupon-pro/admin/coupon-banner/public/css/wt-coupon-banner.css' type='text/css' media='all' />
<link rel='stylesheet' id='wt-smart-coupon-css'  href='https://www.bootstrapdash.com/wp-content/plugins/wt-smart-coupon-pro/public/css/wt-smart-coupon-public.css?ver=1.3.4' type='text/css' media='all' />
<link rel='stylesheet' id='woosb-frontend-css'  href='https://www.bootstrapdash.com/wp-content/plugins/woo-product-bundle-premium/assets/css/frontend.css?ver=5.7.8' type='text/css' media='all' />
<link rel='stylesheet' id='overridingcss-css'  href='https://www.bootstrapdash.com/wp-content/themes/bootstradash/assets/css/overriding.css?ver=5.7.8' type='text/css' media='all' />
<link rel='stylesheet' id='myaccountcss-css'  href='https://www.bootstrapdash.com/wp-content/themes/bootstradash/assets/css/myaccount.css?ver=5.7.8' type='text/css' media='all' />
<link rel='stylesheet' id='singleproductcss-css'  href='https://www.bootstrapdash.com/wp-content/themes/bootstradash/assets/css/singleproduct.css?ver=5.7.8' type='text/css' media='all' />
<link rel='stylesheet' id='productdesccss-css'  href='https://www.bootstrapdash.com/wp-content/themes/bootstradash/assets/css/product-desc.css?ver=5.7.8' type='text/css' media='all' />
<link rel='stylesheet' id='newproductcss-css'  href='https://www.bootstrapdash.com/wp-content/themes/bootstradash/assets/css/new-product-page.css?ver=5.7.8' type='text/css' media='all' />
<link rel='stylesheet' id='pageccss-css'  href='https://www.bootstrapdash.com/wp-content/themes/bootstradash/assets/css/page.css?ver=5.7.8' type='text/css' media='all' />
<link rel='stylesheet' id='ivorystyles-css'  href='https://www.bootstrapdash.com/wp-content/themes/bootstradash/assets/css/ivory-styles.css?ver=5.7.8' type='text/css' media='all' />
<link rel='stylesheet' id='archiveproductcss-css'  href='https://www.bootstrapdash.com/wp-content/themes/bootstradash/assets/css/product-archive.css?ver=5.7.8' type='text/css' media='all' />
<link rel='stylesheet' id='bootstrap-css'  href='https://www.bootstrapdash.com/wp-content/themes/bootstradash/bootstrap/css/bootstrap.min.css?ver=5.7.8' type='text/css' media='all' />
<link rel='stylesheet' id='bootstrapstarter-style-css'  href='https://www.bootstrapdash.com/wp-content/themes/bootstradash/style.css?ver=5.7.8' type='text/css' media='all' />
<link rel='stylesheet' id='commonstyles-css'  href='https://www.bootstrapdash.com/wp-content/themes/bootstradash/assets/css/common.css?ver=5.7.8' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-cdn-css'  href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css?ver=5.7.8' type='text/css' media='all' />
<script type='text/javascript' src='https://www.bootstrapdash.com/wp-includes/js/jquery/jquery.min.js?ver=3.5.1' id='jquery-core-js'></script>
<script type='text/javascript' src='https://www.bootstrapdash.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.3.2' id='jquery-migrate-js'></script>
<script type='text/javascript' id='ajax-auth-script-js-extra'>
/* <![CDATA[ */
var ajax_auth_object = {"ajaxurl":"https:\/\/www.bootstrapdash.com\/wp-admin\/admin-ajax.php","redirecturl":"\/demo\/skydash\/template\/demo\/vertical-default-light\/js\/tabs.js","loadingmessage":"Please wait..."};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.bootstrapdash.com/wp-content/themes/bootstradash/inc/bd-popup/ajax-auth-script.js?ver=5.7.8' id='ajax-auth-script-js'></script>
<script type='text/javascript' src='https://www.bootstrapdash.com/wp-content/plugins/facebook-product-catalog-sync/public/js/facebook-product-catalog-sync-public.js?ver=1.0.0' id='facebook-product-catalog-sync-js'></script>
<script type='text/javascript' id='cookie-law-info-js-extra'>
/* <![CDATA[ */
var Cli_Data = {"nn_cookie_ids":["mailchimp_landing_site","_ga","_gid","_gat_gtag_UA_90680653_2","_hjTLDTest","_hjid","_hjFirstSeen","_hjIncludedInPageviewSample","_hjAbsoluteSessionInProgress","NID","viewed_cookie_policy","cookies.js","tk_ai","tk_qs","tk_tc","tk_or","tk_r3d","tk_lr"],"non_necessary_cookies":{"other":["_hjTLDTest","_hjid","_hjFirstSeen","_hjIncludedInPageviewSample","_hjAbsoluteSessionInProgress","cookies.js","tk_ai","tk_qs","tk_tc"],"analytics":["_ga","_gid","_gat_gtag_UA_90680653_2","tk_or","tk_r3d","tk_lr"],"functional":["mailchimp_landing_site"],"advertisement":["NID"]},"cookielist":{"necessary":{"0":{"ID":36606,"post_author":"1","post_date":"2020-12-22 04:11:33","post_date_gmt":"2020-12-21 22:41:33","post_content":"The cookie is set by the GDPR Cookie Consent plugin and is used to store whether or not user has consented to the use of cookies. It does not store any personal data.","post_title":"viewed_cookie_policy","post_excerpt":"viewed_cookie_policy","post_status":"publish","comment_status":"closed","ping_status":"closed","post_password":"","post_name":"viewed_cookie_policy","to_ping":"","pinged":"","post_modified":"2020-12-22 04:11:33","post_modified_gmt":"2020-12-21 22:41:33","post_content_filtered":"","post_parent":0,"guid":"https:\/\/www.bootstrapdash.com\/cookielawinfo\/viewed_cookie_policy\/","menu_order":0,"post_type":"cookielawinfo","post_mime_type":"","comment_count":"0","filter":"raw"},"1":{"ID":36591,"post_author":"1","post_date":"2020-12-22 04:11:32","post_date_gmt":"2020-12-21 22:41:32","post_content":"This cookie is set by GDPR Cookie Consent plugin. The cookies is used to store the user consent for the cookies in the category ''Necessary''.","post_title":"cookielawinfo-checkbox-necessary","post_excerpt":"cookielawinfo-checkbox-necessary","post_status":"publish","comment_status":"closed","ping_status":"closed","post_password":"","post_name":"cookielawinfo-checkbox-necessary","to_ping":"","pinged":"","post_modified":"2020-12-22 04:11:32","post_modified_gmt":"2020-12-21 22:41:32","post_content_filtered":"","post_parent":0,"guid":"https:\/\/www.bootstrapdash.com\/cookielawinfo\/cookielawinfo-checkbox-necessary\/","menu_order":0,"post_type":"cookielawinfo","post_mime_type":"","comment_count":"0","filter":"raw"},"term_id":54,"name":"Necessary","loadonstart":0,"defaultstate":"enabled","ccpa_optout":0},"other":{"0":{"ID":36600,"post_author":"1","post_date":"2020-12-22 04:11:33","post_date_gmt":"2020-12-21 22:41:33","post_content":"No description","post_title":"_hjTLDTest","post_excerpt":"_hjTLDTest","post_status":"publish","comment_status":"closed","ping_status":"closed","post_password":"","post_name":"_hjtldtest","to_ping":"","pinged":"","post_modified":"2020-12-22 04:11:33","post_modified_gmt":"2020-12-21 22:41:33","post_content_filtered":"","post_parent":0,"guid":"https:\/\/www.bootstrapdash.com\/cookielawinfo\/_hjtldtest\/","menu_order":0,"post_type":"cookielawinfo","post_mime_type":"","comment_count":"0","filter":"raw"},"1":{"ID":36601,"post_author":"1","post_date":"2020-12-22 04:11:33","post_date_gmt":"2020-12-21 22:41:33","post_content":"This cookie is set by Hotjar. This cookie is set when the customer first lands on a page with the Hotjar script. It is used to persist the random user ID, unique to that site on the browser. This ensures that behavior in subsequent visits to the same site will be attributed to the same user ID.","post_title":"_hjid","post_excerpt":"_hjid","post_status":"publish","comment_status":"closed","ping_status":"closed","post_password":"","post_name":"_hjid","to_ping":"","pinged":"","post_modified":"2020-12-22 04:11:33","post_modified_gmt":"2020-12-21 22:41:33","post_content_filtered":"","post_parent":0,"guid":"https:\/\/www.bootstrapdash.com\/cookielawinfo\/_hjid\/","menu_order":0,"post_type":"cookielawinfo","post_mime_type":"","comment_count":"0","filter":"raw"},"2":{"ID":36602,"post_author":"1","post_date":"2020-12-22 04:11:33","post_date_gmt":"2020-12-21 22:41:33","post_content":"No description","post_title":"_hjFirstSeen","post_excerpt":"_hjFirstSeen","post_status":"publish","comment_status":"closed","ping_status":"closed","post_password":"","post_name":"_hjfirstseen","to_ping":"","pinged":"","post_modified":"2020-12-22 04:11:33","post_modified_gmt":"2020-12-21 22:41:33","post_content_filtered":"","post_parent":0,"guid":"https:\/\/www.bootstrapdash.com\/cookielawinfo\/_hjfirstseen\/","menu_order":0,"post_type":"cookielawinfo","post_mime_type":"","comment_count":"0","filter":"raw"},"3":{"ID":36603,"post_author":"1","post_date":"2020-12-22 04:11:33","post_date_gmt":"2020-12-21 22:41:33","post_content":"No description","post_title":"_hjIncludedInPageviewSample","post_excerpt":"_hjIncludedInPageviewSample","post_status":"publish","comment_status":"closed","ping_status":"closed","post_password":"","post_name":"_hjincludedinpageviewsample","to_ping":"","pinged":"","post_modified":"2020-12-22 04:11:33","post_modified_gmt":"2020-12-21 22:41:33","post_content_filtered":"","post_parent":0,"guid":"https:\/\/www.bootstrapdash.com\/cookielawinfo\/_hjincludedinpageviewsample\/","menu_order":0,"post_type":"cookielawinfo","post_mime_type":"","comment_count":"0","filter":"raw"},"4":{"ID":36604,"post_author":"1","post_date":"2020-12-22 04:11:33","post_date_gmt":"2020-12-21 22:41:33","post_content":"No description","post_title":"_hjAbsoluteSessionInProgress","post_excerpt":"_hjAbsoluteSessionInProgress","post_status":"publish","comment_status":"closed","ping_status":"closed","post_password":"","post_name":"_hjabsolutesessioninprogress","to_ping":"","pinged":"","post_modified":"2020-12-22 04:11:33","post_modified_gmt":"2020-12-21 22:41:33","post_content_filtered":"","post_parent":0,"guid":"https:\/\/www.bootstrapdash.com\/cookielawinfo\/_hjabsolutesessioninprogress\/","menu_order":0,"post_type":"cookielawinfo","post_mime_type":"","comment_count":"0","filter":"raw"},"5":{"ID":36607,"post_author":"1","post_date":"2020-12-22 04:11:33","post_date_gmt":"2020-12-21 22:41:33","post_content":"No description","post_title":"cookies.js","post_excerpt":"cookies.js","post_status":"publish","comment_status":"closed","ping_status":"closed","post_password":"","post_name":"cookies-js","to_ping":"","pinged":"","post_modified":"2020-12-22 04:11:33","post_modified_gmt":"2020-12-21 22:41:33","post_content_filtered":"","post_parent":0,"guid":"https:\/\/www.bootstrapdash.com\/cookielawinfo\/cookies-js\/","menu_order":0,"post_type":"cookielawinfo","post_mime_type":"","comment_count":"0","filter":"raw"},"6":{"ID":36608,"post_author":"1","post_date":"2020-12-22 04:11:33","post_date_gmt":"2020-12-21 22:41:33","post_content":"Gathers information for WordPress by themselves, first party analytics tool about how WP services are used. A collection of internal metrics for user activity, used to improve user experience.\r\n","post_title":"tk_ai","post_excerpt":"tk_ai","post_status":"publish","comment_status":"closed","ping_status":"closed","post_password":"","post_name":"tk_ai","to_ping":"","pinged":"","post_modified":"2020-12-22 04:11:33","post_modified_gmt":"2020-12-21 22:41:33","post_content_filtered":"","post_parent":0,"guid":"https:\/\/www.bootstrapdash.com\/cookielawinfo\/tk_ai\/","menu_order":0,"post_type":"cookielawinfo","post_mime_type":"","comment_count":"0","filter":"raw"},"7":{"ID":36609,"post_author":"1","post_date":"2020-12-22 04:11:33","post_date_gmt":"2020-12-21 22:41:33","post_content":"Gathers information for WordPress by themselves, first party analytics tool about how WP services are used. A collection of internal metrics for user activity, used to improve user experience.\r\n","post_title":"tk_qs","post_excerpt":"tk_qs","post_status":"publish","comment_status":"closed","ping_status":"closed","post_password":"","post_name":"tk_qs","to_ping":"","pinged":"","post_modified":"2020-12-22 04:11:33","post_modified_gmt":"2020-12-21 22:41:33","post_content_filtered":"","post_parent":0,"guid":"https:\/\/www.bootstrapdash.com\/cookielawinfo\/tk_qs\/","menu_order":0,"post_type":"cookielawinfo","post_mime_type":"","comment_count":"0","filter":"raw"},"8":{"ID":36610,"post_author":"1","post_date":"2020-12-22 04:11:33","post_date_gmt":"2020-12-21 22:41:33","post_content":"No description","post_title":"tk_tc","post_excerpt":"tk_tc","post_status":"publish","comment_status":"closed","ping_status":"closed","post_password":"","post_name":"tk_tc","to_ping":"","pinged":"","post_modified":"2020-12-22 04:11:33","post_modified_gmt":"2020-12-21 22:41:33","post_content_filtered":"","post_parent":0,"guid":"https:\/\/www.bootstrapdash.com\/cookielawinfo\/tk_tc\/","menu_order":0,"post_type":"cookielawinfo","post_mime_type":"","comment_count":"0","filter":"raw"},"9":{"ID":36592,"post_author":"1","post_date":"2020-12-22 04:11:32","post_date_gmt":"2020-12-21 22:41:32","post_content":"No description","post_title":"cookielawinfo-checkbox-marketing","post_excerpt":"cookielawinfo-checkbox-marketing","post_status":"publish","comment_status":"closed","ping_status":"closed","post_password":"","post_name":"cookielawinfo-checkbox-marketing","to_ping":"","pinged":"","post_modified":"2020-12-22 04:11:32","post_modified_gmt":"2020-12-21 22:41:32","post_content_filtered":"","post_parent":0,"guid":"https:\/\/www.bootstrapdash.com\/cookielawinfo\/cookielawinfo-checkbox-marketing\/","menu_order":0,"post_type":"cookielawinfo","post_mime_type":"","comment_count":"0","filter":"raw"},"term_id":258,"name":"Other","loadonstart":0,"defaultstate":"disabled","ccpa_optout":0},"analytics":{"0":{"ID":36597,"post_author":"1","post_date":"2020-12-22 04:11:33","post_date_gmt":"2020-12-21 22:41:33","post_content":"This cookie is installed by Google Analytics. The cookie is used to calculate visitor, session, campaign data and keep track of site usage for the site''s analytics report. The cookies store information anonymously and assign a randomly generated number to identify unique visitors.","post_title":"_ga","post_excerpt":"_ga","post_status":"publish","comment_status":"closed","ping_status":"closed","post_password":"","post_name":"_ga","to_ping":"","pinged":"","post_modified":"2020-12-22 04:11:33","post_modified_gmt":"2020-12-21 22:41:33","post_content_filtered":"","post_parent":0,"guid":"https:\/\/www.bootstrapdash.com\/cookielawinfo\/_ga\/","menu_order":0,"post_type":"cookielawinfo","post_mime_type":"","comment_count":"0","filter":"raw"},"1":{"ID":36598,"post_author":"1","post_date":"2020-12-22 04:11:33","post_date_gmt":"2020-12-21 22:41:33","post_content":"This cookie is installed by Google Analytics. The cookie is used to store information of how visitors use a website and helps in creating an analytics report of how the wbsite is doing. The data collected including the number visitors, the source where they have come from, and the pages viisted in an anonymous form.","post_title":"_gid","post_excerpt":"_gid","post_status":"publish","comment_status":"closed","ping_status":"closed","post_password":"","post_name":"_gid","to_ping":"","pinged":"","post_modified":"2020-12-22 04:11:33","post_modified_gmt":"2020-12-21 22:41:33","post_content_filtered":"","post_parent":0,"guid":"https:\/\/www.bootstrapdash.com\/cookielawinfo\/_gid\/","menu_order":0,"post_type":"cookielawinfo","post_mime_type":"","comment_count":"0","filter":"raw"},"2":{"ID":36599,"post_author":"1","post_date":"2020-12-22 04:11:33","post_date_gmt":"2020-12-21 22:41:33","post_content":"Google uses this cookie to distinguish users.","post_title":"_gat_gtag_UA_90680653_2","post_excerpt":"_gat_gtag_UA_90680653_2","post_status":"publish","comment_status":"closed","ping_status":"closed","post_password":"","post_name":"_gat_gtag_ua_90680653_2","to_ping":"","pinged":"","post_modified":"2020-12-22 04:11:33","post_modified_gmt":"2020-12-21 22:41:33","post_content_filtered":"","post_parent":0,"guid":"https:\/\/www.bootstrapdash.com\/cookielawinfo\/_gat_gtag_ua_90680653_2\/","menu_order":0,"post_type":"cookielawinfo","post_mime_type":"","comment_count":"0","filter":"raw"},"3":{"ID":36593,"post_author":"1","post_date":"2020-12-22 04:11:32","post_date_gmt":"2020-12-21 22:41:32","post_content":"This cookie is set by JetPack plugin on sites using WooCommerce. This is a referral cookie used for analyzing referrer behavior for Jetpack","post_title":"tk_or","post_excerpt":"tk_or","post_status":"publish","comment_status":"closed","ping_status":"closed","post_password":"","post_name":"tk_or","to_ping":"","pinged":"","post_modified":"2020-12-22 04:11:32","post_modified_gmt":"2020-12-21 22:41:32","post_content_filtered":"","post_parent":0,"guid":"https:\/\/www.bootstrapdash.com\/cookielawinfo\/tk_or\/","menu_order":0,"post_type":"cookielawinfo","post_mime_type":"","comment_count":"0","filter":"raw"},"4":{"ID":36594,"post_author":"1","post_date":"2020-12-22 04:11:32","post_date_gmt":"2020-12-21 22:41:32","post_content":"The cookie is installed by JetPack. Used for the internal metrics fo user activities to improve user experience","post_title":"tk_r3d","post_excerpt":"tk_r3d","post_status":"publish","comment_status":"closed","ping_status":"closed","post_password":"","post_name":"tk_r3d","to_ping":"","pinged":"","post_modified":"2020-12-22 04:11:32","post_modified_gmt":"2020-12-21 22:41:32","post_content_filtered":"","post_parent":0,"guid":"https:\/\/www.bootstrapdash.com\/cookielawinfo\/tk_r3d\/","menu_order":0,"post_type":"cookielawinfo","post_mime_type":"","comment_count":"0","filter":"raw"},"5":{"ID":36595,"post_author":"1","post_date":"2020-12-22 04:11:32","post_date_gmt":"2020-12-21 22:41:32","post_content":"This cookie is set by JetPack plugin on sites using WooCommerce. This is a referral cookie used for analyzing referrer behavior for Jetpack","post_title":"tk_lr","post_excerpt":"tk_lr","post_status":"publish","comment_status":"closed","ping_status":"closed","post_password":"","post_name":"tk_lr","to_ping":"","pinged":"","post_modified":"2020-12-22 04:11:32","post_modified_gmt":"2020-12-21 22:41:32","post_content_filtered":"","post_parent":0,"guid":"https:\/\/www.bootstrapdash.com\/cookielawinfo\/tk_lr\/","menu_order":0,"post_type":"cookielawinfo","post_mime_type":"","comment_count":"0","filter":"raw"},"term_id":259,"name":"Analytics","loadonstart":0,"defaultstate":"disabled","ccpa_optout":0},"functional":{"0":{"ID":36596,"post_author":"1","post_date":"2020-12-22 04:11:33","post_date_gmt":"2020-12-21 22:41:33","post_content":"The cookie is set by the email marketing service MailChimp.","post_title":"mailchimp_landing_site","post_excerpt":"mailchimp_landing_site","post_status":"publish","comment_status":"closed","ping_status":"closed","post_password":"","post_name":"mailchimp_landing_site","to_ping":"","pinged":"","post_modified":"2020-12-22 04:11:33","post_modified_gmt":"2020-12-21 22:41:33","post_content_filtered":"","post_parent":0,"guid":"https:\/\/www.bootstrapdash.com\/cookielawinfo\/mailchimp_landing_site\/","menu_order":0,"post_type":"cookielawinfo","post_mime_type":"","comment_count":"0","filter":"raw"},"term_id":260,"name":"Functional","loadonstart":0,"defaultstate":"disabled","ccpa_optout":0},"advertisement":{"0":{"ID":36605,"post_author":"1","post_date":"2020-12-22 04:11:33","post_date_gmt":"2020-12-21 22:41:33","post_content":"This cookie is used to a profile based on user''s interest and display personalized ads to the users.","post_title":"NID","post_excerpt":"NID","post_status":"publish","comment_status":"closed","ping_status":"closed","post_password":"","post_name":"nid","to_ping":"","pinged":"","post_modified":"2020-12-22 04:11:33","post_modified_gmt":"2020-12-21 22:41:33","post_content_filtered":"","post_parent":0,"guid":"https:\/\/www.bootstrapdash.com\/cookielawinfo\/nid\/","menu_order":0,"post_type":"cookielawinfo","post_mime_type":"","comment_count":"0","filter":"raw"},"term_id":261,"name":"Advertisement","loadonstart":0,"defaultstate":"disabled","ccpa_optout":0}},"ajax_url":"https:\/\/www.bootstrapdash.com\/wp-admin\/admin-ajax.php","current_lang":"en","security":"483aa4eabb","eu_countries":["GB"],"geoIP":"enabled","use_custom_geolocation_api":"","custom_geolocation_api":"https:\/\/geoip.cookieyes.com\/geoip\/checker\/result.php","consentVersion":"1","strictlyEnabled":["necessary","obligatoire"],"cookieDomain":"","privacy_length":"250","ccpaEnabled":"","ccpaRegionBased":"","ccpaBarEnabled":"","ccpaType":"gdpr","triggerDomRefresh":""};
var log_object = {"ajax_url":"https:\/\/www.bootstrapdash.com\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.bootstrapdash.com/wp-content/plugins/webtoffee-gdpr-cookie-consent/public/js/cookie-law-info-public.js?ver=2.3.3' id='cookie-law-info-js'></script>
<script type='text/javascript' src='https://www.bootstrapdash.com/wp-content/plugins/wt-smart-coupon-pro/admin/store-credit/public/js/wt-smart-coupon-store-credit.js?ver=1.3.4' id='wt-smart-coupon-store-credit-js'></script>
<script type='text/javascript' id='wt-smart-coupon-banner-js-extra'>
/* <![CDATA[ */
var WTSmartCouponBannerOBJ = {"ajaxurl":"https:\/\/www.bootstrapdash.com\/wp-admin\/admin-ajax.php","nonce":"22eeb42f48"};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.bootstrapdash.com/wp-content/plugins/wt-smart-coupon-pro/admin/coupon-banner/public/js/wt-coupon-banner.js' id='wt-smart-coupon-banner-js'></script>
<script type='text/javascript' id='wt-smart-coupon-js-extra'>
/* <![CDATA[ */
var WTSmartCouponOBJ = {"ajaxurl":"https:\/\/www.bootstrapdash.com\/wp-admin\/admin-ajax.php","nonces":{"public":"afd1641206","apply_coupon":"22eeb42f48"},"labels":{"please_wait":"Please wait..."}};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.bootstrapdash.com/wp-content/plugins/wt-smart-coupon-pro/public/js/wt-smart-coupon-public.js?ver=1.3.4' id='wt-smart-coupon-js'></script>
<script type='text/javascript' id='jquery-cookie-js-extra'>
/* <![CDATA[ */
var affwp_scripts = {"ajaxurl":"https:\/\/www.bootstrapdash.com\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.bootstrapdash.com/wp-content/plugins/woocommerce/assets/js/jquery-cookie/jquery.cookie.min.js?ver=1.4.1' id='jquery-cookie-js'></script>
<script type='text/javascript' id='affwp-tracking-js-extra'>
/* <![CDATA[ */
var affwp_debug_vars = {"integrations":{"woocommerce":"WooCommerce"},"version":"2.6.8","currency":"USD"};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.bootstrapdash.com/wp-content/plugins/affiliate-wp/assets/js/tracking.min.js?ver=2.6.8' id='affwp-tracking-js'></script>
<script type="text/plain" data-cli-class="cli-blocker-script" data-cli-label="Google Tag Manager"  data-cli-script-type="non-necessary" data-cli-block="true" data-cli-block-if-ccpa-optout="false" data-cli-element-position="head" src='https://www.googletagmanager.com/gtag/js?id=UA-90680653-2' id='google_gtagjs-js' async></script>
<script type='text/javascript' id='google_gtagjs-js-after'>
window.dataLayer = window.dataLayer || [];function gtag(){dataLayer.push(arguments);}
gtag('set', 'linker', {"domains":["www.bootstrapdash.com"]} );
gtag("js", new Date());
gtag("set", "developer_id.dZTNiMT", true);
gtag("config", "UA-90680653-2", {"anonymize_ip":true});
</script>
<link rel="https://api.w.org/" href="https://www.bootstrapdash.com/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://www.bootstrapdash.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://www.bootstrapdash.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.7.8" />
<meta name="generator" content="WooCommerce 5.4.4" />
<meta name="generator" content="Site Kit by Google 1.34.0" />		<script type="text/javascript">
		var AFFWP = AFFWP || {};
		AFFWP.referral_var = 'ref';
		AFFWP.expiration = 60;
		AFFWP.debug = 0;


		AFFWP.referral_credit_last = 1;
		</script>
		<style>#affwp-affiliate-dashboard-order-details td{vertical-align: top;}</style>
			<noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
	<link rel="icon" href="https://www.bootstrapdash.com/wp-content/uploads/2022/02/cropped-logoicon_512x512-32x32.png" sizes="32x32" />
<link rel="icon" href="https://www.bootstrapdash.com/wp-content/uploads/2022/02/cropped-logoicon_512x512-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://www.bootstrapdash.com/wp-content/uploads/2022/02/cropped-logoicon_512x512-180x180.png" />
<meta name="msapplication-TileImage" content="https://www.bootstrapdash.com/wp-content/uploads/2022/02/cropped-logoicon_512x512-270x270.png" />

<!-- Global site tag (gtag.js) - Google Analytics -->
<script type="text/plain" data-cli-class="cli-blocker-script" data-cli-label="Google Tag Manager"  data-cli-script-type="non-necessary" data-cli-block="true" data-cli-block-if-ccpa-optout="false" data-cli-element-position="head" async src="https://www.googletagmanager.com/gtag/js?id=G-GMPSSF7B6Y"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-GMPSSF7B6Y');
</script>
<!--<script type="text/plain" data-cli-class="cli-blocker-script" data-cli-label="Hotjar"  data-cli-script-type="non-necessary" data-cli-block="true" data-cli-block-if-ccpa-optout="false" data-cli-element-position="head">
    (function(h,o,t,j,a,r){
        h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
        h._hjSettings={hjid:847899,hjsv:6};
        a=o.getElementsByTagName('head')[0];
        r=o.createElement('script');r.async=1;
        r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
        a.appendChild(r);
    })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
</script>-->
	<!-- <script>
// Set the date we're counting down to
var countDownDate = new Date("May 14, 2021 23:59:59").getTime();

// Update the count down every 1 second
var x = setInterval(function() {

  // Get today's date and time
  var now = new Date().getTime();

  // Find the distance between now and the count down date
  var distance = countDownDate - now;

  // Time calculations for days, hours, minutes and seconds

  // If the count down is finished, write some text
  if (distance < 0) {
  	clearInterval(x);
  	document.getElementById("bd_offer_timer").remove();
  }
  else{
  	var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  	var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  	var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  	var seconds = Math.floor((distance % (1000 * 60)) / 1000);
  	days=pad(days,2);
  	hours=pad(hours,2);
  	minutes=pad(minutes,2);
  	seconds=pad(seconds,2);
  	document.getElementById('days').innerHTML=days;
  	document.getElementById('hrs').innerHTML=hours;
  	document.getElementById('mins').innerHTML=minutes;
  	document.getElementById('secs').innerHTML=seconds;
  }
}, 1000);
function pad(num, size) {
	num = num.toString();
	while (num.length < size) num = "0" + num;
	return num;
}
</script>  -->
</head>
<body class="error404 theme-bootstradash woocommerce-no-js bootstradash">
	<section class="header">
		<!--<section class="dark-navbar-top">
			<div class="navtop-banner container-fluid px-6">
				<div class="row align-items-center">
					<div class="col-12 text-center">
						<div class="d-md-flex justify-content-center align-items-center">
						<h4 class="wordcarousel d-md-flex text-center align-items-center m-0">

							<span class="large-text d-sm-flex align-items-center">Spring Sale<span class="highlight mx-3">90% OFF</span>--
						<div class="coupon-codes d-flex justify-content-center justify-content-sm-start mt-2 mt-md-0">
							--<span class="small-text mr-1">Use coupon code </span>--
							<div class="lists text-center text-sm-left">
								<ul class="flip2"> 
									<li> <a class="nav-offer" href="/product/star-admin-pro"><span class="large-text d-sm-flex align-items-center">Early Bird Offer&nbsp;<span class="highlight">35% on Star Admin 2&nbsp; </span>   <span class="small-text mr-1">Use code "STAR_35"</span><span class="small-text d-none d-md-flex"> at checkout!</span></a></li>
									<li>
										<a class="nav-offer" href="/summer-sale"><span class="large-text d-sm-flex align-items-center">Summer Sale&nbsp;<span class="highlight">85% OFF &nbsp;</span>   <span class="small-text mr-1">Massive discounts on all template bundles! </span></span></a>
										

									</li>
										 <li>
											<span class="highlight">FLASH20</span> for 20% OFF on all templates!

										</li> 
									</ul>
								</div>
							</div>
						</h4>
							<div class="d-flex timer-bg" id="bd_offer_timer">
								<p>Offer ends in: <span class="highlight"><span id="days"></span>:<span id="hrs"></span>:<span id="mins"></span>:<span id="secs"></span></span></p>
							</div> 
						</div>
					</div>
				</div>
			</div>
		</section> -->

		<header id="header" class="container-fluid px-6">
			<nav class="navbar navbar-expand-lg navbar-light bg-light px-0">
				<a class="navbar-brand " href="https://www.bootstrapdash.com">
					<img src="https://www.bootstrapdash.com/wp-content/themes/bootstradash/images/home-page/new-logo.svg" alt="Bootstrap dash Logo" class="img-fluid" width="184" height="35">				</a>

				<button class="navbar-toggler navbar-light px-0" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
				<div class="collapse navbar-collapse pl-lg-4 pb-lg-0 pb-4" id="navbarTogglerDemo02">

					<div class="menu-header-menu-container"><ul id="menu-header-menu" class="navbar-nav mr-auto mt-2 mt-lg-0"><li id="menu-item-36029" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-36029"><a href="#" class="nav-link">Templates</a>
<ul class="sub-menu">
	<li id="menu-item-68726" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-68726"><a href="https://www.bootstrapdash.com/premium-admin-templates" class="nav-link">All Premium Templates</a></li>
	<li id="menu-item-36077" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-36077"><a href="https://www.bootstrapdash.com/bootstrap-admin-template" class="nav-link">Bootstrap Templates</a></li>
	<li id="menu-item-18912" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-18912"><a href="https://www.bootstrapdash.com/ui-kit/" class="nav-link">UI Kits</a></li>
	<li id="menu-item-19165" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-19165"><a href="https://www.bootstrapdash.com/laravel-templates/" class="nav-link">Laravel Templates</a></li>
	<li id="menu-item-15614" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-15614"><a href="/angular-admin-templates/" class="nav-link">Angular Admin Templates</a></li>
	<li id="menu-item-15893" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-15893"><a href="/react-admin-templates/" class="nav-link">React Admin Templates</a></li>
	<li id="menu-item-15615" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-15615"><a href="/vue-admin-templates/" class="nav-link">Vue Admin Templates</a></li>
	<li id="menu-item-16190" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-16190"><a href="https://www.bootstrapdash.com/material-design-dashboard/" class="nav-link">Material Admin</a></li>
	<li id="menu-item-15617" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-15617"><a href="/html5-basic-template/" class="nav-link">Basic html5 templates</a></li>
</ul>
</li>
<li id="menu-item-16911" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-16911"><a href="#" class="nav-link">Bundles<span class="notification-badge ">UPTO 85% off</span></a>
<ul class="sub-menu">
	<li id="menu-item-20527" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-20527"><a href="https://www.bootstrapdash.com/mega-bundle" class="nav-link">Mega Bundle</a></li>
	<li id="menu-item-20347" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-20347"><a href="https://www.bootstrapdash.com/bootstrap-bundle" class="nav-link">Bootstrap</a></li>
	<li id="menu-item-20346" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-20346"><a href="https://www.bootstrapdash.com/angular-bundle" class="nav-link">Angular</a></li>
	<li id="menu-item-20344" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-20344"><a href="https://www.bootstrapdash.com/react-bundle" class="nav-link">React</a></li>
	<li id="menu-item-20345" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-20345"><a href="https://www.bootstrapdash.com/vue-bundle" class="nav-link">Vue</a></li>
</ul>
</li>
<li id="menu-item-36026" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-36026"><a href="#" class="nav-link">Freebies</a>
<ul class="sub-menu">
	<li id="menu-item-172554" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-172554"><a href="https://www.bootstrapdash.com/all-free-templates" class="nav-link">All Free templates</a></li>
	<li id="menu-item-15618" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-15618"><a href="/bootstrap-free-admin-templates/" class="nav-link">Admin &#038; Dashboards</a></li>
	<li id="menu-item-18911" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-18911"><a href="https://www.bootstrapdash.com/free-ui-kits/" class="nav-link">UI Kits<span class="new-badge">New</span></a></li>
	<li id="menu-item-16191" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-16191"><a href="https://www.bootstrapdash.com/product/material-design-template-free/" class="nav-link">Material Design</a></li>
	<li id="menu-item-15619" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-15619"><a href="/free-landing-page-templates/" class="nav-link">Landing, Pricing and more</a></li>
</ul>
</li>
<li id="menu-item-14766" class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-14766"><a href="https://www.bootstrapdash.com/blog" class="nav-link">Blog</a></li>
<li id="menu-item-118713" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-118713"><a href="https://www.bootstrapdash.com/offers" class="nav-link"><span class="text-danger">Offers</span></a></li>
</ul></div>						<div class="nav-right-item mr-0 ml-auto">
							<ul class="navbar-nav mr-auto align-items-lg-center align-items-start">
								<li class="nav-item">
									<a class="nav-link cart-n-count d-flex" href="https://www.bootstrapdash.com/cart">
										<svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
											<path d="M0.5 1.25C0.5 0.835786 0.835786 0.5 1.25 0.5H1.80826C2.75873 0.5 3.32782 1.13899 3.65325 1.73299C3.87016 2.12894 4.02708 2.58818 4.14982 3.00395C4.18306 3.00134 4.21674 3 4.2508 3H16.7481C17.5783 3 18.1778 3.79442 17.9502 4.5928L16.1224 11.0019C15.7856 12.1832 14.7062 12.9978 13.4779 12.9978H7.52977C6.29128 12.9978 5.2056 12.1699 4.87783 10.9756L4.11734 8.20455L2.85874 3.95578L2.8567 3.94834C2.701 3.38051 2.55487 2.85005 2.33773 2.4537C2.12686 2.0688 1.95877 2 1.80826 2H1.25C0.835786 2 0.5 1.66421 0.5 1.25ZM7 18C8.10457 18 9 17.1046 9 16C9 14.8954 8.10457 14 7 14C5.89543 14 5 14.8954 5 16C5 17.1046 5.89543 18 7 18ZM14 18C15.1046 18 16 17.1046 16 16C16 14.8954 15.1046 14 14 14C12.8954 14 12 14.8954 12 16C12 17.1046 12.8954 18 14 18Z" fill="black"/>
										</svg>

										<div class="round-circle d-flex align-items-center justify-content-center">
											<span>
												0											</span>
										</div>
									</a>
								</li>
								<li class="nav-item ">
									
									<a class="navbar-btn" href="https://www.bootstrapdash.com/my-account" >
										Login/Register									</a>

								</li>


							</ul>
						</div>
										</div>

			</nav>

		</header>
	</section>
	<main>
<div class="container not-found-page py-5 my-md-5">
	<div class="row">
		<img src="https://www.bootstrapdash.com/wp-content/themes/bootstradash/images/404.svg" alt="404" class="mx-auto"/>
	</div>
	<div class="row not-found-title mx-auto text-md-center">
		<h1 class="w-100 mt-4">Oops! That page can’t be found</h1>
	</div>
	<div class="row mx-auto not-found-text">
		<p class="w-100 mb-md-5  text-left text-md-center">Oops! Looks like you followed a bad link. If you think this is a problem with us, please tell us.</p>
	</div>
	<div class="row mx-auto text-md-center">
		<a href="https://www.bootstrapdash.com" class="not-found-btn mx-md-auto">Back to home</a>
	</div>
</div>

<script id="mcjs">!function(c,h,i,m,p){m=c.createElement(h),p=c.getElementsByTagName(h)[0],m.async=1,m.src=i,p.parentNode.insertBefore(m,p)}(document,"script","https://chimpstatic.com/mcjs-connected/js/users/ee767995c9acb17848b80a3cd/b25fb75d419a451f32392f40e.js");</script>	<script type="text/javascript">
		jQuery(document).on('submit','#downloadsModal form#commentform',function(e){
				alert('hi');
				e.preventDefault();
				console.log('hi');
				var commentform=jQuery('#commentform');
				commentform.prepend('<div id="comment-status" ></div>');
				var statusdiv=jQuery('.fetched-data');
				var formdata=commentform.serialize();
				statusdiv.html('<p class="ajax-placeholder">Processing...</p>');
				var formurl=commentform.attr('action');
				jQuery.ajax({
					type: 'post',
					url: formurl,
					data: formdata,
					error: function(XMLHttpRequest, textStatus, errorThrown){
						statusdiv.html('<p class="ajax-error" >You might have left one of the fields blank, or be posting too quickly</p>');
					},
					success: function(data, textStatus){
						var output='';
						if(data=="success"){
							output=output+'<p class="ajax-success my-4 text-center" >Thanks for your comment. We appreciate your response.</p>';
						}
						else
							output=output+'<p class="my-4 text-center">Thanks for your comment. We appreciate your response!</p>';
						if(jQuery('#downloadsModal').hasClass('direct-download')){
							zip=jQuery('#downloadsModal').attr('data-file');
							jQuery('.order_details .downloadfile')
							output=output+'<p class="text-center"><a href="'+zip+'" class="button" id="downloading-now">Download Now</a></p>';
						}
						statusdiv.html(output);
					}
				});
			});
		jQuery(document).ready(function(){
			jQuery(document).on('click','#hideNStartDownload',function(e){
				jQuery('#reviewBeforeDownload').modal('hide');
			});
			jQuery(document).on('click','#proceedToReview',function(e){
				jQuery('#reviewBeforeDownload').modal('hide');
				jQuery('#downloadsModal').modal('show');
			});
			jQuery(document).on('click','#downloading-now',function(e){
				jQuery('#downloadsModal').modal('hide');
			});
			jQuery('#star-rating-empty a').click(function(e){
				e.preventDefault();
				var star   	= jQuery( this );
				var classname=jQuery(this).attr('class');
				var p_id=star.attr('data-id');
				star.siblings( 'a' ).removeClass( 'active' );
				star.addClass( 'active' );

				jQuery.ajax({
					type : 'post',
          			url : ' https://www.bootstrapdash.com/wp-admin/admin-ajax.php', // in here you should put your query 
          			data :  {action:'downloads_review_form',post_id: p_id},
          			success : function(data)
          			{

          				jQuery('#downloadsModal').show();  
          				jQuery('.fetched-data').html(data);

          				jQuery('#downloadsModal .comment-form-rating .stars').addClass( 'selected' );
          				jQuery('#downloadsModal .comment-form-rating a.'+classname).addClass('active');
          				var rating= jQuery( '#downloadsModal' ).find( '#rating' );
          				rating.val( star.text() );
          			}
          		});

			});
			jQuery('#reviewBeforeDownload .proceedtoreview').click(function(e){
				e.preventDefault();
				var p_id=jQuery( this ).attr('data-id');
				//alert(p_id);
				jQuery.ajax({
					type : 'post',
					url : ' https://www.bootstrapdash.com/wp-admin/admin-ajax.php', 
					data :  {
						action:'downloads_review_form',post_id: p_id},
						success : function(data)
						{
							jQuery('#downloadsModal').show();  
							jQuery('#downloadsModal').addClass('direct-download');
							jQuery('.fetched-data').html(data);

						}
					});

			});
			jQuery(document).on('submit','form#updatecommentform',function(e){
				e.preventDefault();
				var c_id=jQuery('#comment_id',this).val();
				var c_content=jQuery('#comment',this).val();
				var c_rating=jQuery('#rating',this).val();
				jQuery.ajax({
					type : 'post',
					url : ' https://www.bootstrapdash.com/wp-admin/admin-ajax.php',  
					data :  {
						action:'downloads_review_form',
						update_id: c_id,
						content:c_content,
						rating:c_rating
					},
					success : function(data)
					{
						jQuery('.fetched-data').html(data);
					}

				});

			});
			jQuery(document).on('submit','form#updatecommentformP',function(e){
				e.preventDefault();
				var c_id=jQuery('#comment_id',this).val();
				var c_content=jQuery('#comment',this).val();
				var c_rating=jQuery('#rating',this).val();
				jQuery.ajax({
					type : 'post',
					url : ' https://www.bootstrapdash.com/wp-admin/admin-ajax.php', 
					data :  {
						action:'downloads_review_form',
						update_id: c_id,
						content:c_content,
						rating:c_rating
					},
					success : function(data)
					{
						jQuery('#ProductReviewModal .fetchedd-data').html(data);
					}

				});

			});
			
			jQuery( document ).on('click', '.woocommerce-order-downloads #downloadfile',function(e){
				e.preventDefault();
				var name=jQuery(this).attr('data-name');
				var pname=jQuery(this).attr('product-name');
				var id=jQuery(this).attr('data-id');
				var zip=jQuery(this).attr('href');
				jQuery('#reviewBeforeDownload').modal('show');
				jQuery('#reviewBeforeDownload span.productname').html(pname);
				jQuery('#reviewBeforeDownload span.pfilename').html(name);
				jQuery('#reviewBeforeDownload .proceedtoreview').attr('data-id',id);
				jQuery('#reviewBeforeDownload .proceedtoreview').attr('data-file',zip);
				jQuery('#downloadsModal').attr('data-file',zip);
				jQuery('#reviewBeforeDownload #hideNStartDownload').attr('href',zip);

			});

		});

function updateComment($cid){

       	//e.preventDefault();
       	var c_id = $cid;
       	//alert(c_id);
       	jQuery.ajax({
       		type : 'post',
           url : ' https://www.bootstrapdash.com/wp-admin/admin-ajax.php', // in here you should put your query 
           data :  {action:'downloads_review_form',comment_id: c_id},
           success : function(data)
           {
              // now you can show output in your modal 
              //jQuery('#downloadsModal').show();  // put your modal id 
              jQuery('.fetched-data').html(data);
          }

      });


       }
       function updateCommentP($cid){
       	var c_id = $cid;
       	//alert(c_id);
       	jQuery.ajax({
       		type : 'post',
           url : ' https://www.bootstrapdash.com/wp-admin/admin-ajax.php', // in here you should put your query 
           data :  {action:'product_review_form',cid: c_id},
           success : function(data)
           {
              // now you can show output in your modal 
              //jQuery('#ProductReviewModal').show();  // put your modal id 
              jQuery('#ProductReviewModal .fetchedd-data').html(data);
          }

      });
       }
   </script>

   	<script type="text/javascript">
		var currentRequest = null; 
		function fetch(){
			var keyword=jQuery('#keyword').val();
			var len=keyword.length;
			if(len<3){
				jQuery('#datafetch').css('display','none');	
				jQuery('#datafetch').parent('.bd-search-results').removeClass('active');	
			}
			else{
				jQuery('#datafetch').css('display','block');
				jQuery('#bd-search-btn').hide();
				jQuery('#bd-search-loader').show();
				jQuery('#datafetch').parent('.bd-search-results').addClass('active');
			}


			currentRequest = jQuery.ajax({

				url: 'https://www.bootstrapdash.com/wp-admin/admin-ajax.php',
				type: 'post',
				data: { action: 'data_fetch', keyword: jQuery('#keyword').val() },
				beforeSend : function()    {           
					if(currentRequest != null) {
						currentRequest.abort();
					}

				},
				success: function(data) {
					jQuery('#bd-search-btn').show();
					jQuery('#bd-search-loader').hide();
					jQuery('#datafetch').html( data );


				}
			});

		}
	</script>

	<div class="wt-cli-cookie-bar-container" data-nosnippet="true"><!--googleoff: all--><div id="cookie-law-info-bar" role="dialog" aria-live="polite" aria-label="cookieconsent" aria-describedby="wt-cli-cookie-banner" data-cli-geo-loc="0" style="text-align:left; padding:15px 30px;" class="wt-cli-cookie-bar"><div class="cli-wrapper"><span id="wt-cli-cookie-banner"><div class="cli-bar-container cli-style-v2"><div class="cli-bar-message">We use cookies on our website to give you the most relevant experience by remembering your preferences and repeat visits. By clicking “Accept”, you consent to the use of ALL the cookies. However you may visit Cookie Settings to provide a controlled consent.</div><div class="cli-bar-btn_container"><a id="wt-cli-settings-btn" tabindex="0" role='button' style="border-bottom:1px solid; text-decoration:none; text-decoration:none;"class="wt-cli-element cli_settings_button"  >Cookie settings</a><a id="wt-cli-accept-btn" tabindex="0" role='button' style="margin:5px 5px 5px 30px; border-radius:0; padding:8px 25px 8px 25px;" data-cli_action="accept"  class="wt-cli-element medium cli-plugin-button cli-plugin-main-button cookie_action_close_header cli_action_button" >ACCEPT</a></div></div></span></div></div><div tabindex="0" id="cookie-law-info-again" style="display:none;"><span id="cookie_hdr_showagain">Manage consent</span></div><div class="cli-modal" id="cliSettingsPopup" role="dialog" aria-labelledby="wt-cli-privacy-title" tabindex="-1" aria-hidden="true">
  <div class="cli-modal-dialog" role="document">
    <div class="cli-modal-content cli-bar-popup">
      <button aria-label="Close" type="button" class="cli-modal-close" id="cliModalClose">
      <svg class="" viewBox="0 0 24 24"><path d="M19 6.41l-1.41-1.41-5.59 5.59-5.59-5.59-1.41 1.41 5.59 5.59-5.59 5.59 1.41 1.41 5.59-5.59 5.59 5.59 1.41-1.41-5.59-5.59z"></path><path d="M0 0h24v24h-24z" fill="none"></path></svg>
      <span class="wt-cli-sr-only">Close</span>
      </button>
        <div class="cli-modal-body">

    <div class="wt-cli-element cli-container-fluid cli-tab-container">
        <div class="cli-row">
                            <div class="cli-col-12 cli-align-items-stretch cli-px-0">
                    <div class="cli-privacy-overview">
                        <h4 id='wt-cli-privacy-title'>Privacy Overview</h4>                        <div class="cli-privacy-content">
                            <div class="cli-privacy-content-text">This website uses cookies to improve your experience while you navigate through the website. Out of these cookies, the cookies that are categorized as necessary are stored on your browser as they as essential for the working of basic functionalities of the website.<br />
We also use third-party cookies that help us analyze and understand how you use this website, to store user preferences and provide them with content that are relevant to you. These cookies will only be stored on your browser with your consent to do so. You also have the option to opt-out of these cookies. But opting out of some of these cookies may have an effect on your browsing experience.</div>
                        </div>
                        <a id="wt-cli-privacy-readmore"  tabindex="0" role="button" class="cli-privacy-readmore" data-readmore-text="Show more" data-readless-text="Show less"></a>                    </div>
                </div>
                        <div class="cli-col-12 cli-align-items-stretch cli-px-0 cli-tab-section-container">

                
                                    <div class="cli-tab-section">
                        <div class="cli-tab-header">
                            <a id="wt-cli-tab-link-necessary" tabindex="0" role="tab" aria-expanded="false" aria-describedby="wt-cli-tab-necessary" aria-controls="wt-cli-tab-necessary" class="cli-nav-link cli-settings-mobile" data-target="necessary" data-toggle="cli-toggle-tab">
                                Necessary                            </a>
                                                                                        <div class="wt-cli-necessary-checkbox">
                                    <input type="checkbox" class="cli-user-preference-checkbox" id="wt-cli-checkbox-necessary" aria-label="Necessary" data-id="checkbox-necessary" checked="checked" />
                                    <label class="form-check-label" for="wt-cli-checkbox-necessary"> Necessary </label>
                                </div>
                                <span class="cli-necessary-caption">
                                    Always Enabled                                </span>
                                                    </div>
                        <div class="cli-tab-content">
                            <div id="wt-cli-tab-necessary" tabindex="0" role="tabpanel" aria-labelledby="wt-cli-tab-link-necessary" class="cli-tab-pane cli-fade" data-id="necessary">
                                <p>These required cookies allow you to access/use our services, navigate our platform and access relevant information about your account. Disabling or removing these cookies will impact the delivery of services on our Sites. For example of these cookies is authentication cookie that authenticate users for the duration of their visit.</p>
                            </div>
                        </div>
                    </div>
                                    <div class="cli-tab-section">
                        <div class="cli-tab-header">
                            <a id="wt-cli-tab-link-other" tabindex="0" role="tab" aria-expanded="false" aria-describedby="wt-cli-tab-other" aria-controls="wt-cli-tab-other" class="cli-nav-link cli-settings-mobile" data-target="other" data-toggle="cli-toggle-tab">
                                Other                            </a>
                                                                                        <div class="cli-switch">
                                    <input type="checkbox" class="cli-user-preference-checkbox"  id="wt-cli-checkbox-other" aria-label="other" data-id="checkbox-other" role="switch" aria-controls="wt-cli-tab-link-other" aria-labelledby="wt-cli-tab-link-other"  />
                                    <label for="wt-cli-checkbox-other" class="cli-slider" data-cli-enable="Enabled" data-cli-disable="Disabled"><span class="wt-cli-sr-only">other</span></label>
                                </div>
                                                    </div>
                        <div class="cli-tab-content">
                            <div id="wt-cli-tab-other" tabindex="0" role="tabpanel" aria-labelledby="wt-cli-tab-link-other" class="cli-tab-pane cli-fade" data-id="other">
                                <p>Other uncategorized cookies are those that are being analyzed and have not been classified into a category as yet.</p>
                            </div>
                        </div>
                    </div>
                                    <div class="cli-tab-section">
                        <div class="cli-tab-header">
                            <a id="wt-cli-tab-link-analytics" tabindex="0" role="tab" aria-expanded="false" aria-describedby="wt-cli-tab-analytics" aria-controls="wt-cli-tab-analytics" class="cli-nav-link cli-settings-mobile" data-target="analytics" data-toggle="cli-toggle-tab">
                                Analytics                            </a>
                                                                                        <div class="cli-switch">
                                    <input type="checkbox" class="cli-user-preference-checkbox"  id="wt-cli-checkbox-analytics" aria-label="analytics" data-id="checkbox-analytics" role="switch" aria-controls="wt-cli-tab-link-analytics" aria-labelledby="wt-cli-tab-link-analytics"  />
                                    <label for="wt-cli-checkbox-analytics" class="cli-slider" data-cli-enable="Enabled" data-cli-disable="Disabled"><span class="wt-cli-sr-only">analytics</span></label>
                                </div>
                                                    </div>
                        <div class="cli-tab-content">
                            <div id="wt-cli-tab-analytics" tabindex="0" role="tabpanel" aria-labelledby="wt-cli-tab-link-analytics" class="cli-tab-pane cli-fade" data-id="analytics">
                                <p>Analytical cookies are used to understand how visitors interact with the website. These cookies help provide information on metrics the number of visitors, bounce rate, traffic source, etc.</p>
                            </div>
                        </div>
                    </div>
                                    <div class="cli-tab-section">
                        <div class="cli-tab-header">
                            <a id="wt-cli-tab-link-functional" tabindex="0" role="tab" aria-expanded="false" aria-describedby="wt-cli-tab-functional" aria-controls="wt-cli-tab-functional" class="cli-nav-link cli-settings-mobile" data-target="functional" data-toggle="cli-toggle-tab">
                                Functional                            </a>
                                                                                        <div class="cli-switch">
                                    <input type="checkbox" class="cli-user-preference-checkbox"  id="wt-cli-checkbox-functional" aria-label="functional" data-id="checkbox-functional" role="switch" aria-controls="wt-cli-tab-link-functional" aria-labelledby="wt-cli-tab-link-functional"  />
                                    <label for="wt-cli-checkbox-functional" class="cli-slider" data-cli-enable="Enabled" data-cli-disable="Disabled"><span class="wt-cli-sr-only">functional</span></label>
                                </div>
                                                    </div>
                        <div class="cli-tab-content">
                            <div id="wt-cli-tab-functional" tabindex="0" role="tabpanel" aria-labelledby="wt-cli-tab-link-functional" class="cli-tab-pane cli-fade" data-id="functional">
                                <p>Functional cookies help to perform certain functionalities like sharing the content of the website on social media platforms, collect feedbacks, and other third-party features.</p>
                            </div>
                        </div>
                    </div>
                                    <div class="cli-tab-section">
                        <div class="cli-tab-header">
                            <a id="wt-cli-tab-link-advertisement" tabindex="0" role="tab" aria-expanded="false" aria-describedby="wt-cli-tab-advertisement" aria-controls="wt-cli-tab-advertisement" class="cli-nav-link cli-settings-mobile" data-target="advertisement" data-toggle="cli-toggle-tab">
                                Advertisement                            </a>
                                                                                        <div class="cli-switch">
                                    <input type="checkbox" class="cli-user-preference-checkbox"  id="wt-cli-checkbox-advertisement" aria-label="advertisement" data-id="checkbox-advertisement" role="switch" aria-controls="wt-cli-tab-link-advertisement" aria-labelledby="wt-cli-tab-link-advertisement"  />
                                    <label for="wt-cli-checkbox-advertisement" class="cli-slider" data-cli-enable="Enabled" data-cli-disable="Disabled"><span class="wt-cli-sr-only">advertisement</span></label>
                                </div>
                                                    </div>
                        <div class="cli-tab-content">
                            <div id="wt-cli-tab-advertisement" tabindex="0" role="tabpanel" aria-labelledby="wt-cli-tab-link-advertisement" class="cli-tab-pane cli-fade" data-id="advertisement">
                                <p>Advertisement cookies are used to provide visitors with relevant ads and marketing campaigns. These cookies track visitors across websites and collect information to provide customized ads.</p>
                            </div>
                        </div>
                    </div>
                
            </div>
        </div>
    </div>
</div>
<div class="cli-modal-footer">
    <div class="wt-cli-element cli-container-fluid cli-tab-container">
        <div class="cli-row">
            <div class="cli-col-12 cli-align-items-stretch cli-px-0">
                <div class="cli-tab-footer wt-cli-privacy-overview-actions">
                    
                        
                                                    <a id="wt-cli-privacy-save-btn" role="button" tabindex="0" data-cli-action="accept" class="wt-cli-privacy-btn cli_setting_save_button wt-cli-privacy-accept-btn cli-btn">Save & Accept</a>
                                            
                </div>
                            </div>
        </div>
    </div>
</div>
    </div>
  </div>
</div>
<div class="cli-modal-backdrop cli-fade cli-settings-overlay"></div>
<div class="cli-modal-backdrop cli-fade cli-popupbar-overlay"></div>
<!--googleon: all--></div>
<script type="text/javascript">
  /* <![CDATA[ */
    cli_cookiebar_settings='{"animate_speed_hide":"500","animate_speed_show":"500","background":"#fffffff7","border":"#b1a6a6c2","border_on":false,"button_1_button_colour":"#61a229","button_1_button_hover":"#4e8221","button_1_link_colour":"#fff","button_1_as_button":true,"button_1_new_win":false,"button_2_button_colour":"#ffffff","button_2_button_hover":"#cccccc","button_2_link_colour":"#898888","button_2_as_button":false,"button_2_hidebar":false,"button_2_nofollow":false,"button_3_button_colour":"#61a229","button_3_button_hover":"#4e8221","button_3_link_colour":"#fff","button_3_as_button":true,"button_3_new_win":false,"button_4_button_colour":"#ffffff","button_4_button_hover":"#cccccc","button_4_link_colour":"#898888","button_4_as_button":false,"button_7_button_colour":"#61a229","button_7_button_hover":"#4e8221","button_7_link_colour":"#fff","button_7_as_button":true,"button_7_new_win":false,"font_family":"inherit","header_fix":false,"notify_animate_hide":true,"notify_animate_show":false,"notify_div_id":"#cookie-law-info-bar","notify_position_horizontal":"right","notify_position_vertical":"bottom","scroll_close":false,"scroll_close_reload":false,"accept_close_reload":false,"reject_close_reload":false,"showagain_tab":true,"showagain_background":"#fff","showagain_border":"#000","showagain_div_id":"#cookie-law-info-again","showagain_x_position":"100px","text":"#333","show_once_yn":false,"show_once":"10000","logging_on":false,"as_popup":false,"popup_overlay":true,"bar_heading_text":"","cookie_bar_as":"banner","cookie_setting_popup":true,"accept_all":true,"js_script_blocker":false,"popup_showagain_position":"bottom-right","widget_position":"left","button_1_style":[["margin","5px 5px 5px 30px"],["border-radius","0"],["padding","8px 25px 8px 25px"]],"button_2_style":[],"button_3_style":[["margin","5px 5px 5px 5px"],["border-radius","0"],["padding","8px 25px 8px 25px"]],"button_4_style":[["border-bottom","1px solid"],["text-decoration","none"],["text-decoration","none"]],"button_5_style":[["float","right"],["text-decoration","none"],["color","#333"]],"button_7_style":[["margin","5px 5px 5px 30px"],["border-radius","0"],["padding","8px 25px 8px 25px"]],"accept_close_page_navigation":false}';
  /* ]]> */
</script>
	<script type="text/javascript">
		(function () {
			var c = document.body.className;
			c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
			document.body.className = c;
		})();
	</script>
	<script type='text/javascript' id='thickbox-js-extra'>
/* <![CDATA[ */
var thickboxL10n = {"next":"Next >","prev":"< Prev","image":"Image","of":"of","close":"Close","noiframes":"This feature requires inline frames. You have iframes disabled or your browser does not support them.","loadingAnimation":"https:\/\/www.bootstrapdash.com\/wp-includes\/js\/thickbox\/loadingAnimation.gif"};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.bootstrapdash.com/wp-includes/js/thickbox/thickbox.js?ver=3.1-20121105' id='thickbox-js'></script>
<script type='text/javascript' src='https://www.bootstrapdash.com/wp-includes/js/dist/vendor/wp-polyfill.min.js?ver=7.4.4' id='wp-polyfill-js'></script>
<script type='text/javascript' id='wp-polyfill-js-after'>
( 'fetch' in window ) || document.write( '<script src="https://www.bootstrapdash.com/wp-includes/js/dist/vendor/wp-polyfill-fetch.min.js?ver=3.0.0"></scr' + 'ipt>' );( document.contains ) || document.write( '<script src="https://www.bootstrapdash.com/wp-includes/js/dist/vendor/wp-polyfill-node-contains.min.js?ver=3.42.0"></scr' + 'ipt>' );( window.DOMRect ) || document.write( '<script src="https://www.bootstrapdash.com/wp-includes/js/dist/vendor/wp-polyfill-dom-rect.min.js?ver=3.42.0"></scr' + 'ipt>' );( window.URL && window.URL.prototype && window.URLSearchParams ) || document.write( '<script src="https://www.bootstrapdash.com/wp-includes/js/dist/vendor/wp-polyfill-url.min.js?ver=3.6.4"></scr' + 'ipt>' );( window.FormData && window.FormData.prototype.keys ) || document.write( '<script src="https://www.bootstrapdash.com/wp-includes/js/dist/vendor/wp-polyfill-formdata.min.js?ver=3.0.12"></scr' + 'ipt>' );( Element.prototype.matches && Element.prototype.closest ) || document.write( '<script src="https://www.bootstrapdash.com/wp-includes/js/dist/vendor/wp-polyfill-element-closest.min.js?ver=2.0.2"></scr' + 'ipt>' );( 'objectFit' in document.documentElement.style ) || document.write( '<script src="https://www.bootstrapdash.com/wp-includes/js/dist/vendor/wp-polyfill-object-fit.min.js?ver=2.3.4"></scr' + 'ipt>' );
</script>
<script type='text/javascript' id='contact-form-7-js-extra'>
/* <![CDATA[ */
var wpcf7 = {"api":{"root":"https:\/\/www.bootstrapdash.com\/wp-json\/","namespace":"contact-form-7\/v1"}};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.bootstrapdash.com/wp-content/plugins/contact-form-7/includes/js/index.js?ver=5.4.1' id='contact-form-7-js'></script>
<script type='text/javascript' src='https://www.bootstrapdash.com/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.70' id='jquery-blockui-js'></script>
<script type='text/javascript' id='wc-add-to-cart-js-extra'>
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View cart","cart_url":"https:\/\/www.bootstrapdash.com\/checkout","is_cart":"","cart_redirect_after_add":"yes"};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.bootstrapdash.com/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=5.4.4' id='wc-add-to-cart-js'></script>
<script type='text/javascript' src='https://www.bootstrapdash.com/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min.js?ver=2.1.4' id='js-cookie-js'></script>
<script type='text/javascript' id='woocommerce-js-extra'>
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%"};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.bootstrapdash.com/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=5.4.4' id='woocommerce-js'></script>
<script type='text/javascript' id='wc-cart-fragments-js-extra'>
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","cart_hash_key":"wc_cart_hash_c0ddd8821bf4f675c13dfabd7b8ef7e8","fragment_name":"wc_fragments_c0ddd8821bf4f675c13dfabd7b8ef7e8","request_timeout":"5000"};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.bootstrapdash.com/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min.js?ver=5.4.4' id='wc-cart-fragments-js'></script>
<script type='text/javascript' id='mailchimp-woocommerce-js-extra'>
/* <![CDATA[ */
var mailchimp_public_data = {"site_url":"https:\/\/www.bootstrapdash.com","ajax_url":"https:\/\/www.bootstrapdash.com\/wp-admin\/admin-ajax.php","language":"en"};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.bootstrapdash.com/wp-content/plugins/mailchimp-for-woocommerce/public/js/mailchimp-woocommerce-public.min.js?ver=2.5.1' id='mailchimp-woocommerce-js'></script>
<script type='text/javascript' id='woosb-frontend-js-extra'>
/* <![CDATA[ */
var woosb_vars = {"version":"5.7.2","alert_selection":"Please select some product options for [name] before adding this bundle to the cart.","alert_empty":"Please choose at least one product before adding this bundle to the cart.","alert_min":"Please choose at least [min] in the whole products before adding this bundle to the cart.","alert_max":"Please choose maximum [max] in the whole products before adding this bundle to the cart.","price_text":"","saved_text":"(saved [d])","summary_selector":".summary","container_selector":"","change_image":"yes","bundled_price":"price","bundled_price_from":"sale_price","change_price":"yes","price_selector":"","price_format":"%1$s%2$s","price_decimals":"2","price_thousand_separator":",","price_decimal_separator":".","currency_symbol":"$"};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.bootstrapdash.com/wp-content/plugins/woo-product-bundle-premium/assets/js/frontend.js?ver=5.7.2' id='woosb-frontend-js'></script>
<script type='text/javascript' src='https://www.bootstrapdash.com/wp-content/themes/bootstradash/bootstrap/js/bootstrap.bundle.min.js?ver=3.3.6' id='bootstrap-js'></script>
<script type='text/javascript' id='ajaxjs-js-extra'>
/* <![CDATA[ */
var ajax_auth_object = {"ajaxurl":"https:\/\/www.bootstrapdash.com\/wp-admin\/admin-ajax.php","redirecturl":"https:\/\/www.bootstrapdash.com\/thank-you","loadingmessage":"Sending user info, please wait..."};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.bootstrapdash.com/wp-content/themes/bootstradash/assets/js/ajax-login-script.js' id='ajaxjs-js'></script>
<script type='text/javascript' src='https://www.bootstrapdash.com/wp-content/themes/bootstradash/assets/js/bd.js' id='bdjs-js'></script>
<script type='text/javascript' src='https://www.google.com/recaptcha/api.js?render=6Lcng78ZAAAAAAlIAChJmw0ioywcIci9P5thyefw&#038;ver=3.0' id='google-recaptcha-js'></script>
<script type='text/javascript' id='wpcf7-recaptcha-js-extra'>
/* <![CDATA[ */
var wpcf7_recaptcha = {"sitekey":"6Lcng78ZAAAAAAlIAChJmw0ioywcIci9P5thyefw","actions":{"homepage":"homepage","contactform":"contactform"}};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.bootstrapdash.com/wp-content/plugins/contact-form-7/modules/recaptcha/index.js?ver=5.4.1' id='wpcf7-recaptcha-js'></script>
<script type='text/javascript' id='ivory-search-scripts-js-extra'>
/* <![CDATA[ */
var IvorySearchVars = {"is_analytics_enabled":"1"};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.bootstrapdash.com/wp-content/plugins/add-search-to-menu/public/js/ivory-search.min.js?ver=4.6.4' id='ivory-search-scripts-js'></script>
<script type='text/javascript' src='https://www.bootstrapdash.com/wp-includes/js/wp-embed.min.js?ver=5.7.8' id='wp-embed-js'></script>
</main>
<footer>
<div class="container-fluid py-5 px-6">
	<div class=" footer1 ">
		<div><div class="textwidget custom-html-widget">	<div class="row">
													<div class="col-12 col-lg-8">
															<div class="row">
																	<div class="col-12 col-xl-3 col-sm-6 mb-5">
																			<div class="">
																					<h3 class="footer-title">Products</h3>
																					<ul>
																							<li>
																									<a href="/premium-admin-templates/">Templates</a>
																							</li>
																							<li>
																									<a href="/free-landing-page-templates/">Free Themes</a>
																							</li>
																							<li>
																									<a href="/mega-bundle/">Bundles</a>
																							</li>
																							<li>
																									<a href="/ui-kit/">UI Kits</a>
																							</li>
																					</ul>
																			</div>
																	</div>
																	<div class="col-12 col-xl-3 col-sm-6 mb-5">
																			<div class="">
																					<h3 class="footer-title">Resources</h3>
																					<ul>
																							<li>
																									<a href="/bootstrap-4-tutorial/introduction/">Bootstrap Tutorial</a>
																							</li>
																							<li>
																									<a href="/custom-ui-development/">Custom UI Development</a>
																							</li>
																							<li>
																									<a href="/blog/">Blog</a>
																							</li>
																					</ul>
																			</div>
																	</div>
																	<div class="col-12 col-xl-3 col-sm-6 mb-5">
																			<div class="">
																					<h3 class="footer-title">Company</h3>
																					<ul>
																							<li>
																									<a href="/about-us/">About us</a>
																							</li>
																							<li>
																									<a href="/affiliate/">Become an affiliate</a>
																							</li>
																							<li>
																									<a href="https://bootstrapdash.freshdesk.com/support/tickets/new">Get support</a>
																							</li>
																					</ul>
																			</div>
																	</div>
																	<div class="col-12 col-xl-3 col-sm-6 mb-5">
																			<div class="">
																					<h3 class="footer-title">Legal</h3>
																					<ul>
																							<li>
																									<a href="/license/">Product License</a>
																							</li>
																							<li>
																									<a href="/terms-conditions/">Terms & Conditions</a>
																							</li>
																							<li>
																									<a href="/privacy-policy/">Privacy Policy</a>
																							</li>
																							<li>
																									<a href="/cookie-policy/">Cookie Policy</a>
																							</li>
																					</ul>
																			</div>
																	</div>
															</div>
													</div>
													<div class="col-12 col-lg-4">
															<div class="news-letter">
																	<h3 class="footer-title">Want more Bootstrap themes, templates, and UI tools?</h3>
																	<p>Subscribe to get updated when new templates release and to get special discount codes every month!</p>
																	<!-- Begin Mailchimp Signup Form -->
																	<div id="mc_embed_signup">
																			<form action="https://bootstrapdash.us4.list-manage.com/subscribe/post-json?u=ee767995c9acb17848b80a3cd&amp;id=d4565d388e&c=?" method="get" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" target="_blank" novalidate>
																					<div id="mc_embed_signup_scroll">
																							<div id="mce-responses" class="clear">
																									<div class="response" id="mce-error-response" style="display:none"></div>
																									<div class="response" id="mce-success-response" style="display:none"></div>
																							</div>    <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
																							<div style="position: absolute; left: -5000px;" aria-hidden="true"><input type="text" name="b_ee767995c9acb17848b80a3cd_d4565d388e" tabindex="-1" value=""></div>
																							<div class="mc-field-group input-group">
																									<input type="email" value="" name="mceEmail" class="form-control required email" id="mce-EMAIL" placeholder="Enter your email">
																									<div class="input-group-append">
																											<button type="submit" value="Subscribe" name="subscribe" id="mc-embedded-subscribe" class="button ">
																													<svg width="16" height="16" viewbox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
																															<path d="M8 0L6.59 1.41L12.17 7H0V9H12.17L6.59 14.59L8 16L16 8L8 0Z" fill="white"/>
																													</svg>

																											</button>
																									</div>
																							</div>
																					</div>
																			</form>
																			<p id="subscribeMsg" class="small mt-2 mb-0"></p>
																	</div>

																	<!--End mc_embed_signup-->
															</div>
													</div>
											</div></div></div>		
	</div>
	<div class="footer2 mb-5 mt-5 mt-lg-0">
		<div><div class="textwidget custom-html-widget"><div class="row">
						<div class="col-12">
							<h3 class="footer-title">Follow us on</h3>
							<div class="social-icons d-sm-flex text-center text-sm-left">
								<a href="https://www.facebook.com/bootstrapdash"><svg width="24" height="24" viewbox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
									<path d="M21.9963 0.738281H1.97919C1.29378 0.738693 0.738144 1.2946 0.738281 1.98029V21.9974C0.738693 22.6828 1.2946 23.2384 1.98029 23.2383H12.7573V14.5371H9.83496V11.1313H12.7573V8.62495C12.7573 5.71838 14.5318 4.13635 17.1245 4.13635C18.3664 4.13635 19.4336 4.22891 19.7446 4.27025V7.30811H17.9567C16.5461 7.30811 16.2729 7.97841 16.2729 8.96223V11.1313H19.6458L19.2063 14.5371H16.2729V23.2383H21.9963C22.6821 23.2384 23.2381 22.6826 23.2383 21.9968C23.2383 21.9967 23.2383 21.9966 23.2383 21.9963V1.97919C23.238 1.29378 22.682 0.738144 21.9963 0.738281Z" fill="#B8BABE"/>
								</svg></a>
								<a href="https://www.instagram.com/bootstrapdash/"><svg width="24" height="24" viewbox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
									<g clip-path="url(#clip0)">
										<path d="M23.9773 7.05607C23.9211 5.78085 23.7149 4.90416 23.4195 4.14449C23.1147 3.33812 22.6459 2.61617 22.0316 2.01602C21.4315 1.40652 20.7048 0.932921 19.9077 0.632936C19.1437 0.337529 18.2715 0.131312 16.9963 0.0750879C15.7116 0.0141019 15.3037 0 12.0453 0C8.78685 0 8.379 0.0141019 7.09903 0.0703262C5.82381 0.126551 4.94712 0.332951 4.18763 0.628174C3.38108 0.932922 2.65914 1.40176 2.05898 2.01602C1.44949 2.61617 0.976072 3.34288 0.675904 4.13991C0.380498 4.90416 0.174281 5.77609 0.118057 7.0513C0.0570706 8.33604 0.0429688 8.7439 0.0429688 12.0023C0.0429688 15.2608 0.0570706 15.6686 0.113295 16.9486C0.169519 18.2238 0.375919 19.1005 0.671326 19.8602C0.976072 20.6666 1.44949 21.3885 2.05898 21.9887C2.65914 22.5982 3.38584 23.0718 4.18287 23.3718C4.94712 23.6672 5.81905 23.8734 7.09445 23.9296C8.37424 23.986 8.78227 23.9999 12.0407 23.9999C15.2992 23.9999 15.707 23.986 16.987 23.9296C18.2622 23.8734 19.1389 23.6672 19.8984 23.3718C21.5113 22.7482 22.7865 21.4729 23.4101 19.8602C23.7053 19.096 23.9117 18.2238 23.968 16.9486C24.0242 15.6686 24.0383 15.2608 24.0383 12.0023C24.0383 8.7439 24.0335 8.33604 23.9773 7.05607ZM21.8161 16.8549C21.7644 18.027 21.5675 18.6599 21.4034 19.0819C21.0002 20.1274 20.1703 20.9572 19.1248 21.3605C18.7028 21.5246 18.0653 21.7215 16.8978 21.7729C15.6319 21.8293 15.2523 21.8433 12.0501 21.8433C8.84784 21.8433 8.46343 21.8293 7.20213 21.7729C6.03003 21.7215 5.3971 21.5246 4.97514 21.3605C4.45484 21.1682 3.98123 20.8634 3.59682 20.4649C3.19831 20.0758 2.89356 19.6069 2.70126 19.0866C2.53717 18.6647 2.34029 18.027 2.28883 16.8596C2.23242 15.5937 2.2185 15.2139 2.2185 12.0117C2.2185 8.80946 2.23242 8.42505 2.28883 7.16394C2.34029 5.99183 2.53717 5.3589 2.70126 4.93694C2.89356 4.41645 3.19831 3.94303 3.60158 3.55843C3.99057 3.15992 4.45941 2.85517 4.9799 2.66306C5.40186 2.49896 6.03955 2.30209 7.2069 2.25044C8.47277 2.19422 8.8526 2.18011 12.0546 2.18011C15.2616 2.18011 15.6413 2.19422 16.9026 2.25044C18.0747 2.30209 18.7076 2.49896 19.1296 2.66306C19.6499 2.85517 20.1235 3.15992 20.5079 3.55843C20.9064 3.94761 21.2111 4.41645 21.4034 4.93694C21.5675 5.3589 21.7644 5.99641 21.8161 7.16394C21.8723 8.42981 21.8864 8.80946 21.8864 12.0117C21.8864 15.2139 21.8723 15.589 21.8161 16.8549Z" fill="#B8BABE"/>
										<path d="M12.0442 5.83691C8.64049 5.83691 5.87891 8.59832 5.87891 12.0022C5.87891 15.406 8.64049 18.1674 12.0442 18.1674C15.448 18.1674 18.2094 15.406 18.2094 12.0022C18.2094 8.59832 15.448 5.83691 12.0442 5.83691ZM12.0442 16.0014C9.83604 16.0014 8.04492 14.2105 8.04492 12.0022C8.04492 9.79386 9.83604 8.00293 12.0442 8.00293C14.2525 8.00293 16.0434 9.79386 16.0434 12.0022C16.0434 14.2105 14.2525 16.0014 12.0442 16.0014Z" fill="#B8BABE"/>
										<path d="M19.8925 5.59336C19.8925 6.3882 19.248 7.03267 18.453 7.03267C17.6581 7.03267 17.0137 6.3882 17.0137 5.59336C17.0137 4.79835 17.6581 4.15405 18.453 4.15405C19.248 4.15405 19.8925 4.79835 19.8925 5.59336Z" fill="#B8BABE"/>
									</g>
									<defs>
										<clippath id="clip0">
											<rect width="24" height="24" fill="white"/>
										</clippath>
									</defs>
								</svg></a>
								<a href="https://twitter.com/bootstrapdash"><svg width="24" height="24" viewbox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
									<path d="M7.81828 21.0103C16.3093 21.0103 20.9527 13.9757 20.9527 7.87588C20.9527 7.67609 20.9485 7.47712 20.9396 7.27926C21.8409 6.6276 22.6242 5.81439 23.2423 4.88878C22.4152 5.25657 21.5249 5.50384 20.5913 5.6157C21.5443 5.04399 22.2761 4.13997 22.6212 3.0623C21.7293 3.59109 20.7414 3.97526 19.6899 4.18276C18.8476 3.28549 17.6481 2.72437 16.3202 2.72437C13.771 2.72437 11.7036 4.79163 11.7036 7.33994C11.7036 7.70237 11.7442 8.05462 11.8233 8.39256C7.9867 8.19951 4.58446 6.36272 2.30791 3.56949C1.91163 4.25156 1.68294 5.04412 1.68294 5.8898C1.68294 7.49116 2.49793 8.90525 3.73714 9.73221C2.9798 9.70896 2.26842 9.50105 1.64648 9.15499C1.64579 9.17439 1.64579 9.19324 1.64579 9.21388C1.64579 11.4496 3.23697 13.3162 5.3495 13.7392C4.96148 13.8447 4.55323 13.9016 4.13218 13.9016C3.83524 13.9016 3.54574 13.8724 3.26449 13.8183C3.85217 15.6525 5.55645 16.9872 7.57693 17.0246C5.9969 18.263 4.00655 19.0006 1.84338 19.0006C1.47132 19.0006 1.10352 18.9793 0.742188 18.9367C2.78524 20.2462 5.21122 21.0104 7.81842 21.0104" fill="#B8BABE"/>
								</svg></a>
								<a href="https://www.linkedin.com/in/bootstrapdash/"><svg width="24" height="24" viewbox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
									<path d="M3.46687 1.21899C1.817 1.21899 0.738281 2.30238 0.738281 3.72635C0.738281 5.11887 1.78487 6.23315 3.40356 6.23315H3.43488C5.11702 6.23315 6.16388 5.11887 6.16388 3.72635C6.13243 2.30238 5.11702 1.21899 3.46687 1.21899Z" fill="#B8BABE"/>
									<path d="M1.02344 8.21436H5.84671V22.7253H1.02344V8.21436Z" fill="#B8BABE"/>
									<path d="M17.6858 7.87354C15.0838 7.87354 13.339 10.3185 13.339 10.3185V8.21411H8.51562V22.7252H13.3388V14.6216C13.3388 14.1878 13.3702 13.7547 13.4977 13.4444C13.8463 12.5782 14.6398 11.6807 15.9723 11.6807C17.7177 11.6807 18.4157 13.0114 18.4157 14.9622V22.7252H23.2386V14.4048C23.2386 9.94762 20.8589 7.87354 17.6858 7.87354Z" fill="#B8BABE"/>
								</svg></a>
								<a href="https://dribbble.com/bootstrapdash"><svg width="24" height="24" viewbox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
									<g clip-path="url(#clip0)">
										<path d="M12 0.000976562C5.38313 0.000976562 0 5.3841 0 12.0008C0 18.6176 5.38313 24.0007 12 24.0007C18.6169 24.0007 24 18.6176 24 12.0008C24 5.3841 18.6169 0.000976562 12 0.000976562ZM19.8199 5.6604C21.1671 7.31866 21.9965 9.41172 22.0654 11.6933C19.57 11.1767 17.3103 11.2374 15.3155 11.6285C14.9543 10.7838 14.5804 9.97908 14.203 9.21854C16.3755 8.28266 18.2667 7.08733 19.8199 5.6604ZM18.4681 4.28652C16.9264 5.69379 15.1397 6.73576 13.3102 7.50504C11.9674 5.0495 10.6826 3.20036 9.9 2.14953C10.5777 2.00515 11.2799 1.9277 12 1.9277C14.4607 1.9277 16.7169 2.81579 18.4681 4.28652ZM7.95402 2.77879C8.545 3.5446 9.95267 5.46207 11.4648 8.19018C7.66449 9.42829 3.97701 9.63689 2.20507 9.65629C2.94364 6.57096 5.10427 4.03399 7.95402 2.77879ZM1.93725 11.5879C1.95626 11.5879 1.97463 11.588 1.99403 11.588C3.21839 11.588 5.46161 11.5057 8.1025 11.0241C9.6092 10.7494 11.0379 10.3796 12.3785 9.92128C12.7275 10.6168 13.0745 11.3505 13.4109 12.1195C11.5337 12.7239 9.95074 13.5935 8.69683 14.4569C6.59414 15.9049 5.12109 17.5114 4.31675 18.5047C2.82753 16.7484 1.92672 14.4785 1.92672 12.0008C1.92672 11.8624 1.9316 11.7251 1.93725 11.5879ZM5.70515 19.8566C6.39761 18.9847 7.80707 17.3977 9.84593 16.0052C11.2315 15.0588 12.665 14.3557 14.1407 13.8942C14.9969 16.1135 15.7279 18.5657 16.1638 21.1695C14.8937 21.7485 13.4846 22.074 12 22.074C9.6196 22.074 7.43097 21.2423 5.70515 19.8566ZM17.9364 20.132C17.4872 17.7407 16.8173 15.4922 16.0429 13.4373C17.9478 13.1159 19.9165 13.1822 21.9385 13.6364C21.5025 16.294 20.0236 18.604 17.9364 20.132Z" fill="#B8BABE"/>
									</g>
									<defs>
										<clippath id="clip1">
											<rect width="24" height="24" fill="white"/>
										</clippath>
									</defs>
								</svg></a>
							<a href="https://github.com/BootstrapDash">	<svg width="24" height="24" viewbox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
									<g clip-path="url(#clip0)">
										<path d="M12 0.500244C5.37 0.500244 0 5.78024 0 12.2922C0 17.5032 3.438 21.9222 8.205 23.4802C8.805 23.5912 9.025 23.2262 9.025 22.9132C9.025 22.6332 9.015 21.8912 9.01 20.9082C5.672 21.6192 4.968 19.3262 4.968 19.3262C4.422 17.9652 3.633 17.6012 3.633 17.6012C2.546 16.8702 3.717 16.8852 3.717 16.8852C4.922 16.9672 5.555 18.1002 5.555 18.1002C6.625 19.9032 8.364 19.3822 9.05 19.0812C9.158 18.3182 9.467 17.7992 9.81 17.5042C7.145 17.2092 4.344 16.1952 4.344 11.6772C4.344 10.3902 4.809 9.33824 5.579 8.51324C5.444 8.21524 5.039 7.01624 5.684 5.39224C5.684 5.39224 6.689 5.07624 8.984 6.60124C9.944 6.33924 10.964 6.20924 11.984 6.20324C13.004 6.20924 14.024 6.33924 14.984 6.60124C17.264 5.07624 18.269 5.39224 18.269 5.39224C18.914 7.01624 18.509 8.21524 18.389 8.51324C19.154 9.33824 19.619 10.3902 19.619 11.6772C19.619 16.2072 16.814 17.2042 14.144 17.4942C14.564 17.8482 14.954 18.5712 14.954 19.6762C14.954 21.2542 14.939 22.5222 14.939 22.9052C14.939 23.2142 15.149 23.5832 15.764 23.4652C20.565 21.9172 24 17.4952 24 12.2922C24 5.78024 18.627 0.500244 12 0.500244Z" fill="#B8BABE"/>
									</g>
									<defs>
										<clippath id="clip2">
											<rect width="24" height="24" fill="white"/>
										</clippath>
									</defs>
								</svg></a>

							</div>
						</div>
					</div></div></div> 
		
	</div>
	<div class="footer3 pt-5 border-top">
		<div><div class="textwidget custom-html-widget"><div class="row">
						<div class="col-12 col-md-9">
							
							<div class="">
								<p class="mb-0 ">© 2021 BootstrapDash - All right reserved</p>
							</div>
						</div>
						<div class="col-12 col-md-3 mt-5 mt-md-0 text-center text-md-right text-sm-left">
							<img src="/wp-content/themes/bootstradash/images/payment-cards.svg" alt="payment-cards">
						</div>

					</div></div></div>	</div>
</div>
</footer>
</body>
</html>